<template>
  <div class="app"></div>
</template>

<script>
export default {};
</script>

<style>
html,
body {
  width: 100%;
  height: 100%;
}
</style>
